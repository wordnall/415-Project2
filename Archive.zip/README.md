Will Lucic, Andrew Langwell

Run project2.py (we used python interpreter 3.5.1) enter values for a and b then choose which task to run.
'task1' for task1, 'task2' for task2, 'q' to quit.
Task1 example:
    Enter the value for A: 241
    Enter the value for B: 123
    Which task would you like to run? (task1, task2, q):task1
    Running Karatsubas large interger multiplication
    The product is:  29643
Task2 example:
    Enter the value for A: 256
    Enter the value for B: 10
    Which task would you like to run? (task1, task2, q):task2
    Running exponentiator using karatsuba multiplication
    The product is:  1208925819614629174706176